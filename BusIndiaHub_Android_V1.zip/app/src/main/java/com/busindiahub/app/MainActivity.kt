package com.busindiahub.app
import android.app.Activity
import android.os.Bundle
import android.webkit.WebView
import android.webkit.WebViewClient
class MainActivity: Activity(){
 private lateinit var w:WebView
 override fun onCreate(b:Bundle?){super.onCreate(b);w=WebView(this);w.settings.javaScriptEnabled=true;w.settings.domStorageEnabled=true;w.webViewClient=WebViewClient();setContentView(w);w.loadUrl("file:///android_asset/index.html")}
 override fun onBackPressed(){if(w.canGoBack())w.goBack()else super.onBackPressed()}
}